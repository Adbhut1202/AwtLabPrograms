
var express = require('express')
var path = require('path')

var app = new express()
app.use(express.urlencoded())

app.use(express.static("public")) 

app.get("/",(req,res)=>{
  res.sendFile(path.join(__dirname,"index.html"))
})

app.post('/signin', (req, res)=> {
  var name= req.body.uname;
  res.send("<html><body><h1> Hello "+name+"</h1></body></html>")
});

app.listen(1202,()=>{
  console.log("server started...")
})