var express = require("express")
var app= new express()

app.get("/",(req,res)=>{
    res.write("In the Get Method ... ")
    res.end()
})

app.post("/post",(req,res)=>{
    res.write("In the Post Method ... ")
    res.end()
})

app.delete("/del",(req,res)=>{
    res.write("In the Delete Method ... ")
    res.end()

})

app.put("/put",(req,res)=>{
    res.write("In the Put Method ... ")
    res.end()
})

app.listen((1202),()=>{
    console.log("Server started ...")
})